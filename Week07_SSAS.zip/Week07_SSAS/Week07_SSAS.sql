USE StagingTable
-- State --
CREATE TABLE [StateTable]
(
 [State FIPS] Int IDENTITY(1,1) PRIMARY KEY NOT NULL,
 [State Name] nvarchar(max),
 [State Abbreviation] nvarchar(max),
 [Part D Prescribers] INT,
 [Part D Opioid Prescribers] INT,
 [Opioid Claims] INT,
 [Extended Release Opioid Claims] INT,
 [Overall Claims] INT,
 [Opioid Prescribing Rate] Float,
 [Extended Release Opioid Prescribing Rate] Float
)

INSERT INTO [StateTable]([State Name], [State Abbreviation], [Part D Prescribers],[Part D Opioid Prescribers], [Opioid Claims],[Extended Release Opioid Claims], [Overall Claims], [Opioid Prescribing Rate], [Extended Release Opioid Prescribing Rate]) 
SELECT [State Name], [State Abbreviation], [Part D Prescribers],
[Part D Opioid Prescribers], [Opioid Claims],[Extended Release Opioid Claims], 
[Overall Claims], [Opioid Prescribing Rate], [Extended Release Opioid Prescribing Rate] 
FROM StateDestination

--Creating FactTable
CREATE TABLE [State_Fact]
(
 [Fips] Int PRIMARY KEY NOT NULL,
 [State Code] Char(2) NOT NULL,
 [Name] Varchar(max) NOT NULL,
 FOREIGN KEY ([Fips]) REFERENCES StateTable([State FIPS])
)

INSERT INTO [State_Fact]
SELECT [State Abbreviation],[State Name],[State FIPS]  FROM [StateTable]

Select * from State_Fact

--County--

CREATE TABLE [CountyTable]
(
 [FIPS] Int IDENTITY(1,1) PRIMARY KEY NOT NULL,
 [State Name] Varchar(max) NULL,
 [State Abbreviation] varchar(max) NULL,
 [County Name] Varchar(max) NULL,
 [Part D Prescribers] Float NULL,
 [Part D Opioid Prescribers] Float NULL,
 [Opioid Claims] Float NULL,
 [Extended Release Opioid Claims] Float NULL,
 [Overall Claims] Float NULL,
 [Opioid Prescribing Rate] Float NULL,
 [Extended Release Opioid Prescribing Rate] Float NULL
)

INSERT INTO [CountyTable]([State Name], [State Abbreviation], [County Name], [Part D Prescribers], [Part D Opioid Prescribers], [Opioid Claims], [Extended Release Opioid Claims], [Overall Claims], [Opioid Prescribing Rate], [Extended Release Opioid Prescribing Rate]) 
SELECT [State Name], [State Abbreviation], [County Name],
 [Part D Prescribers], [Part D Opioid Prescribers], [Opioid Claims], 
 [Extended Release Opioid Claims], [Overall Claims], [Opioid Prescribing Rate],
  [Extended Release Opioid Prescribing Rate] FROM CountyDesination

Select * from countytable

CREATE TABLE [County_Fact]
(
 [FIPS] Int PRIMARY KEY NOT NULL,
 [County Name] Varchar(max) NULL,
 [State] Varchar(max) NULL
 FOREIGN KEY ([Fips]) REFERENCES County_Table([FIPS])
)

INSERT INTO [County_Fact]
SELECT [FIPS],[County Name],[State Name]  FROM countytable

--Zip--

CREATE TABLE [ZipTable]
(
 [Zip Code] Int IDENTITY(1001,1) PRIMARY KEY NOT NULL,
 [State Name] Varchar(max) NULL,
 [State Abbreviation] Varchar(max) NULL,
 [Part D Prescribers] Float NULL,
 [Part D Opioid Prescribers] Float NULL,
 [Opioid Claims] Float NULL,
 [Extended Release Opioid Claims] Float NULL,
 [Overall Claims] Float NULL,
 [Opioid Prescribing Rate] Float NULL,
 [Extended Release Opioid Prescribing Rate] Float NULL
)


INSERT INTO [ZipTable]([State Name], [State Abbreviation], [Part D Prescribers], [Part D Opioid Prescribers], 
[Opioid Claims], [Extended Release Opioid Claims], [Overall Claims], [Opioid Prescribing Rate], [Extended Release Opioid Prescribing Rate]) 
SELECT [State Name], [State Abbreviation], [Part D Prescribers],
 [Part D Opioid Prescribers], [Opioid Claims], [Extended Release Opioid Claims],
  [Overall Claims], [Opioid Prescribing Rate], [Extended Release Opioid Prescribing Rate] 
  FROM ZipDestination


CREATE TABLE Zip_Fact
(
 [Zip Code] INT PRIMARY KEY NOT NULL,
 [State Abbreviation] Varchar(max) NULL,
 [State] varchar(max) NULL,
  FOREIGN KEY ([Zip Code]) REFERENCES Zip_Table([Zip Code])
)

INSERT INTO Zip_Fact
SELECT [Zip Code],[State Abbreviation],[State Name]  FROM Ziptable

DELETE FROM ZipTable
where [State Name] IS NULL

DELETE FROM Zip_Fact
where [State] IS NULL

Select * from Zip_Fact
